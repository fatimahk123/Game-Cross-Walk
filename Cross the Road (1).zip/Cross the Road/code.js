var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----



var life=0;
var score=0;


var w1 = createSprite(200, 100, 400, 5);
w1.shapeColor="yellow";
var w2 = createSprite(200, 300, 400, 5);
w2.shapeColor="yellow";
var p1 = createSprite(200, 200, 50, 400);
p1.shapeColor="beige";


var house = createSprite(200, 390, 100, 50);
house.shapeColor="brown";
var park = createSprite(200, 10, 400, 175);
park.shapeColor="green";
var Sophia = createSprite(200, 390, 15, 15);
Sophia.shapeColor="pink";

var c1 = createSprite(390, 120, 20, 15);
c1.shapeColor="orange";
c1.velocityX=-20;
var c2 = createSprite(10, 280, 20, 15);
c2.shapeColor="blue";
c2.velocityX=20;
var c3 = createSprite(10, 180, 20, 15);
c3.shapeColor="red";
c3.velocityX=20;
var c4 = createSprite(390, 220, 20, 15);
c4.shapeColor="purple";
c4.velocityX=-20;




var co1 = createSprite(195, 200, 10, 10);
co1.shapeColor="yellow";
var co2 = createSprite(205, 240, 10 ,10);
co2.shapeColor="yellow";
var co3 = createSprite(200, 300, 10,10);
co3.shapeColor="yellow";
var co4 = createSprite(200, 140, 10, 10);
co4.shapeColor="yellow";

function draw() {
  background("black");
  
  textSize(15);
  stroke("turquoise");
  fill("pink");
  text("Score:"+score,330,350);
 
  textSize(15);
  stroke("turquoise");
  fill("white");
  text("Lives:"+life,30,350);
 
  noStroke();
  fill("white");
  textSize(10);
  text("Welcome! Help Sophia get to the ",0,370);
  text(" park without hitting any cars ",0,380);
  text("and collecting the most coins.",0,390);
  if (Sophia.isTouching(c1)|| Sophia.isTouching(c2)||Sophia.isTouching(c3) || Sophia.isTouching(c4)) {
    life=life+1;
    score=1;
    Sophia.x=200;
    Sophia.y=390;
  }

  if(Sophia.isTouching(park)){
    stroke("gold");
    fill("white");
    textSize(40);
    strokeWeight(10);
    text("Game over!",140,200);
    stroke("lightbrowne");
    fill("white");
    textSize(25);
    strokeWeight(5);
    text("You Won!",140,250);
    p1.destroy();
    Sophia.velocityY=0;
    Sophia.velocityX=0;
  }
  
  if (Sophia.isTouching(co1)) {
  co1.destroy();
  score=score+1;
}
  
  if (Sophia.isTouching(co2)) {
    co2.destroy();
    score=score+1;
  }
  
  if (Sophia.isTouching(co3)) {
    co3.destroy();
    score=score+1;
  }
  
  if (Sophia.isTouching(co4)) {
    co4.destroy();
    score=score+1;
  }
  
  if (keyDown("up")) {
    Sophia.y=Sophia.y-7;
    
  }
  
  if (keyDown("down")) {
    Sophia.y=Sophia.y+7;
    
  }
  
  
   stroke("white");
   strokeWeight(1);
   noFill();
   for (var i = 0; i < 400; i=i+20) {
    line(i,200,i+10,200);
  }
  
  stroke("white");
  strokeWeight(1);
  noFill();
  for (var i = 0; i < 400; i=i+20) {
    line(i,150,i+10,150);
  }
  
  stroke("white");
  strokeWeight(1);
  noFill();
  for (var i = 0; i < 400; i=i+20) {
    line(i,250,i+10,250);
  }
 createEdgeSprites();
  c1.bounceOff(rightEdge);
  c1.bounceOff(leftEdge);
  c2.bounceOff(rightEdge);
  c2.bounceOff(leftEdge);
  c3.bounceOff(rightEdge);
  c3.bounceOff(leftEdge);
  c4.bounceOff(rightEdge);
  c4.bounceOff(leftEdge);
  Sophia.collide(topEdge);
  Sophia.collide(bottomEdge);


 drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
